﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deon_Output
{
    class Program
    {
        static void Main(string[] args)
        {
            print("My First Assignment. My Name is Deon.");
            Console.Read();
        }

        static void print(string msg) { System.Console.Write(msg); }
    }
}
