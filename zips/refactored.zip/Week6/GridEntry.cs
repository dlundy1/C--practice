﻿namespace Week6
{
    public class GridEntry
    {
        public bool Hit;
        public Ship Ship;
    }
}
