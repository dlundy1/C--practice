﻿namespace Week6
{
    public enum PlayMode
    {
        Delay,
        Pause,
    }
}
