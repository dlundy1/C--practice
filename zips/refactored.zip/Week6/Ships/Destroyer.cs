﻿using System;

namespace Week6
{
    class Destroyer : Ship
    {
        public Destroyer() : base(3, ConsoleColor.DarkRed, ShipTypes.Destroyer)
        {

        }

    }
}
