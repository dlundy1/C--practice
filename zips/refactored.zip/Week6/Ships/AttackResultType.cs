﻿namespace Week6
{
    public enum AttackResultType
    {
        Miss,
        Hit,
        Sank,
    }
}
