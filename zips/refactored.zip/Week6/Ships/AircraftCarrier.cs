﻿using System;

namespace Week6
{ 
    class AircraftCarrier : Ship
    {
        public AircraftCarrier() : base(5, ConsoleColor.Blue, ShipTypes.AircraftCarrier)
        {

        }

    }
}
