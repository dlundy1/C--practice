﻿namespace Week6
{
    public enum ShipTypes
    {
        None,
        PatrolBoat,
        Submarine,
        Destroyer,
        AircraftCarrier,
        Battleship,
    }
}
