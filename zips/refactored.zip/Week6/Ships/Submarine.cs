﻿using System;

namespace Week6
{
    class Submarine : Ship
    {
        public Submarine() : base(3, ConsoleColor.Cyan, ShipTypes.Submarine)
        {

        }

    }
}
