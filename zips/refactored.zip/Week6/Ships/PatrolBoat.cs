﻿using System;

namespace Week6
{
    class PatrolBoat : Ship
    {
        public PatrolBoat() : base(2, ConsoleColor.White, ShipTypes.PatrolBoat)
        {

        }

    }
}
