﻿namespace Week6
{
    public enum Direction
    {
        Horizontal,
        Vertical,
    }
}